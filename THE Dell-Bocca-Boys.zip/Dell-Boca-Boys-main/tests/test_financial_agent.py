"""
Tests for the FinancialAnalystAgent.  These tests exercise the
offline paths to ensure the agent degrades gracefully when network
access is unavailable and verify basic accounting operations using
sample data.
"""

from core.financial_agent import FinancialAnalystAgent


def test_daily_picks_length():
    agent = FinancialAnalystAgent()
    picks = agent.generate_daily_picks(num_picks=2)
    assert picks["status"] == "ok"
    assert len(picks["stock_picks"]) == 2
    assert len(picks["crypto_picks"]) == 2


def test_market_summary_offline_error():
    agent = FinancialAnalystAgent()
    summary = agent.get_daily_market_summary()
    # In this offline environment all prices should be None
    assert summary["status"] in ("ok", "error")
    # When no data is available, ensure error detail is provided
    if summary["status"] == "error":
        assert "unavailable" in summary["detail"].lower()


def test_accounting_summary():
    agent = FinancialAnalystAgent()
    summary = agent.get_accounting_summary()
    # We expect either a valid summary or a clear error
    assert summary["status"] in ("ok", "error")
    if summary["status"] == "ok":
        assert isinstance(summary.get("summary"), dict)