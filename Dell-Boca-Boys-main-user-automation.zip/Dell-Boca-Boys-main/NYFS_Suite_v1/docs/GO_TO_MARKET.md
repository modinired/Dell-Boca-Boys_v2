# GO-TO-MARKET (GTM) STARTER

## Positioning
- **Value**: CFO-grade reporting and insights at a fraction of the cost.
- **Speed**: Days to onboard, hours to produce recurring reporting.

## Pricing
- **Entry**: $199–$399/mo for single-entity monthly reporting.
- **Plus**: $699–$1,499/mo adds forecasting & inventory.
- **Premium**: $2,000+/mo multi-entity consolidation & custom KPIs.

## Wedge
- Offer free **Company Health Snapshot** (Insights + KPIs) from their last 6 months of data.
- Upsell ongoing reporting & automation.
