﻿using System;
using System.Linq;

namespace WorkflowCore.Sample04
{
    public class MyDataClass
    {
        public string Value1 { get; set; }
    }
}
