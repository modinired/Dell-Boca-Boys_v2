﻿namespace WorkflowCore.Interface
{
    public interface IBackgroundTask
    {
        void Start();
        void Stop();
    }
}