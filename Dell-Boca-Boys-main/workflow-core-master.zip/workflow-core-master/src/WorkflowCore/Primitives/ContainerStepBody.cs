﻿using System.Linq;
using WorkflowCore.Models;

namespace WorkflowCore.Primitives
{
    public abstract class ContainerStepBody : StepBody
    {
        
    }
}
