﻿using System;
using WorkflowCore.Interface;
using WorkflowCore.Models;

namespace WorkflowCore.Primitives
{
    public class SubWorkflowStepBody : StepBody
    {
        public override ExecutionResult Run(IStepExecutionContext context)
        {
            // TODO: What is this supposed to do?
            throw new NotImplementedException();
        }
    }
}
