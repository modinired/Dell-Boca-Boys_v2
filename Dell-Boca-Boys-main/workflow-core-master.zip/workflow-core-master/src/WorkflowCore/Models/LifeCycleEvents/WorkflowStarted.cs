﻿using System;

namespace WorkflowCore.Models.LifeCycleEvents
{
    public class WorkflowStarted : LifeCycleEvent
    {
    }
}
