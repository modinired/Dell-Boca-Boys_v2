﻿using System;

namespace WorkflowCore.Models.LifeCycleEvents
{
    public class WorkflowResumed : LifeCycleEvent
    {
    }
}
