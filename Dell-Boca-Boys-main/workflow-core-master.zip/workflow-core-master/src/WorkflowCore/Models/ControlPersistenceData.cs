﻿namespace WorkflowCore.Models
{
    public class ControlPersistenceData
    {
        public bool ChildrenActive { get; set; }
    }
}
