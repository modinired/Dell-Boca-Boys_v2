﻿using System;

namespace WorkflowCore.Models.Search
{
    public class StepInfo
    {
        public int StepId { get; set; }

        public string Name { get; set; }
    }
}
