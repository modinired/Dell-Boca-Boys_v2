﻿namespace WorkflowCore.Models
{
    public class SchedulePersistenceData
    {
        public bool Elapsed { get; set; }

    }
}
