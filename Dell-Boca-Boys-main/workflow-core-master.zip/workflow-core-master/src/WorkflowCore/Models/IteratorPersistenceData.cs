﻿namespace WorkflowCore.Models
{
    public class IteratorPersistenceData : ControlPersistenceData
    {
        public int Index { get; set; } = 0;
    }
}
