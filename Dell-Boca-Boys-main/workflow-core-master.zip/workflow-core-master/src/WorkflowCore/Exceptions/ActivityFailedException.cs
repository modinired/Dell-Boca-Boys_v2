using System;

namespace WorkflowCore.Exceptions
{
    public class ActivityFailedException : Exception
    {
        public ActivityFailedException(object data)
        {
            //
        }
    }
}