using System;

namespace WorkflowCore.Exceptions
{
    public class WorkflowLockedException : Exception
    {
        public WorkflowLockedException(): base()
        {
            //
        }
    }
}