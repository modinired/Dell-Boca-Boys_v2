﻿using System;

namespace WorkflowCore.Exceptions
{
    public class CorruptPersistenceDataException : Exception
    {
    }
}
