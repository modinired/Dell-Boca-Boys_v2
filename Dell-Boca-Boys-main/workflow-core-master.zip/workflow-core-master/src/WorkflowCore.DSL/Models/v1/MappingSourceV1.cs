﻿using System;

namespace WorkflowCore.Models.DefinitionStorage.v1
{
    public class MappingSourceV1
    {
        public string Value { get; set; }

        public string Property { get; set; }
    }
}
