﻿using System;
using System.Linq;

namespace WorkflowCore.Users.Models
{
    public class UserAction
    {
        public string User { get; set; }
        public object OutcomeValue { get; set; }
    }
}
