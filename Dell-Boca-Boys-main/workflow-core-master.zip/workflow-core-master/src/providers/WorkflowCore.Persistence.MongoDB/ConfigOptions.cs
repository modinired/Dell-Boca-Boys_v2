﻿using System;
using System.Linq;

namespace WorkflowCore.Persistence.MongoDB
{
    public class ConfigOptions
    {
        public string DatabaseServer { get; set; }
        public string DatabaseName { get; set; }
    }
}
