
from .utils import ValidationError

def validate_shape(obj, shape):
    req = shape.get("required", [])
    props = shape.get("properties", {})
    for r in req:
        if r not in obj:
            raise ValidationError(f"Missing required property: {r}")
    for k, spec in props.items():
        if k in obj and "type" in spec:
            py = {"string": str, "number": (int,float), "boolean": bool, "object": dict, "array": list}.get(spec["type"])
            if py and not isinstance(obj[k], py):
                raise ValidationError(f"Property {k} expected {spec['type']}")
    return True
