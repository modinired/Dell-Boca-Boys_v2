
import json, os, csv
from .db import connect

def export_jsonld(conn, path):
    items = []
    for n in conn.execute("SELECT * FROM nodes").fetchall():
        props = json.loads(n["properties"] or "{}")
        obj = {"@id": f"node:{n['id']}", "@type": n["type"], "label": n["label"]}
        if n["pid_type"] and n["pid"]:
            obj[n["pid_type"]] = n["pid"]
        obj.update(props)
        items.append(obj)
    preds = {r["id"]: r["name"] for r in conn.execute("SELECT id,name FROM predicates")}
    for t in conn.execute("SELECT * FROM triples").fetchall():
        p = preds[t["pred"]]
        items.append({"@id": f"triple:{t['id']}", "@type": "Triple",
                      "subject": f"node:{t['subj']}", "predicate": p, "object": f"node:{t['obj']}",
                      "properties": json.loads(t["properties"] or "{}")})
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"@context": {"node":"urn:node/","triple":"urn:triple/"}, "@graph": items}, f, ensure_ascii=False, indent=2)

def export_neo4j_csv(conn, dirpath):
    os.makedirs(dirpath, exist_ok=True)
    with open(os.path.join(dirpath, "nodes.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id:ID", "label:STRING", "type:LABEL", "pid_type:STRING", "pid:STRING", "properties:STRING"])
        for n in conn.execute("SELECT * FROM nodes").fetchall():
            w.writerow([n["id"], n["label"], n["type"], n["pid_type"] or "", n["pid"] or "", n["properties"] or "{}"])
    with open(os.path.join(dirpath, "edges.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([":START_ID", ":END_ID", ":TYPE", "properties:STRING"])
        preds = {r["id"]: r["name"] for r in conn.execute("SELECT id,name FROM predicates")}
        for t in conn.execute("SELECT * FROM triples").fetchall():
            w.writerow([t["subj"], t["obj"], preds[t["pred"]], t["properties"] or "{}"])
