
import json, time, urllib.request, urllib.parse

class APIClient:
    def __init__(self, base_url, headers=None, rate_limit_per_sec=5):
        self.base = base_url.rstrip("/")
        self.headers = headers or {}
        self.min_interval = 1.0 / float(rate_limit_per_sec)
        self._last = 0.0

    def get(self, path, params=None):
        now = time.time()
        wait = self._last + self.min_interval - now
        if wait > 0:
            time.sleep(wait)
        self._last = time.time()
        url = self.base + path
        if params:
            url += "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers=self.headers)
        with urllib.request.urlopen(req) as resp:
            data = resp.read().decode("utf-8")
            return json.loads(data)

class NIHReporter(APIClient):
    pass

class NSFAwards(APIClient):
    pass

class ORCID(APIClient):
    pass

class USPTO(APIClient):
    pass
