
import argparse, json, os
from .db import connect, init_db
from .ontology import add_node_type, add_predicate
from .kg import create_node, create_triple, add_evidence
from .exporters import export_jsonld, export_neo4j_csv

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--db", required=True)
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init")

    nt = sub.add_parser("add-node-type")
    nt.add_argument("--name", required=True)
    nt.add_argument("--desc", default="")

    pr = sub.add_parser("add-predicate")
    pr.add_argument("--name", required=True)
    pr.add_argument("--domain", required=True)
    pr.add_argument("--range", required=True)
    pr.add_argument("--schema", default="{}")
    pr.add_argument("--desc", default="")

    ln = sub.add_parser("create-node")
    ln.add_argument("--type", required=True)
    ln.add_argument("--label", required=True)
    ln.add_argument("--pid-type", default=None)
    ln.add_argument("--pid", default=None)
    ln.add_argument("--props", default="{}")

    tr = sub.add_parser("create-triple")
    tr.add_argument("--subj", type=int, required=True)
    tr.add_argument("--pred", required=True)
    tr.add_argument("--obj", type=int, required=True)
    tr.add_argument("--props", default="{}")

    ev = sub.add_parser("add-evidence")
    ev.add_argument("--triple", type=int, required=True)
    ev.add_argument("--node", type=int, required=True)

    ex = sub.add_parser("export-jsonld")
    ex.add_argument("--out", required=True)

    nx = sub.add_parser("export-neo4j")
    nx.add_argument("--outdir", required=True)

    args = p.parse_args()
    conn = connect(args.db)

    if args.cmd == "init":
        init_db(conn)
        print(json.dumps({"ok": True, "message": "initialized"}, indent=2))

    elif args.cmd == "add-node-type":
        add_node_type(conn, args.name, args.desc)
        print(json.dumps({"ok": True}, indent=2))

    elif args.cmd == "add-predicate":
        add_predicate(conn, args.name, args.domain, args.range, json.loads(args.schema), args.desc)
        print(json.dumps({"ok": True}, indent=2))

    elif args.cmd == "create-node":
        nid = create_node(conn, args.type, args.label, args.pid_type, args.pid, json.loads(args.props))
        print(json.dumps({"ok": True, "node_id": nid}, indent=2))

    elif args.cmd == "create-triple":
        tid = create_triple(conn, args.subj, args.pred, args.obj, json.loads(args.props))
        print(json.dumps({"ok": True, "triple_id": tid}, indent=2))

    elif args.cmd == "add-evidence":
        add_evidence(conn, args.triple, args.node)
        print(json.dumps({"ok": True}, indent=2))

    elif args.cmd == "export-jsonld":
        export_jsonld(conn, args.out)
        print(json.dumps({"ok": True, "out": args.out}, indent=2))

    elif args.cmd == "export-neo4j":
        export_neo4j_csv(conn, args.outdir)
        print(json.dumps({"ok": True, "outdir": args.outdir}, indent=2))

if __name__ == "__main__":
    main()
