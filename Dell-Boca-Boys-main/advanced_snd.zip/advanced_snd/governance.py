
import json
from .db import connect

def record_model(conn, name, version, params=None, uri=None):
    conn.execute("INSERT OR REPLACE INTO models(name,version,params,uri,created_at) VALUES(?,?,?,?,datetime('now'))",
                 (name, version, json.dumps(params or {}), uri))
    conn.commit()

def record_dataset(conn, name, version, uri=None, schema=None):
    conn.execute("INSERT OR REPLACE INTO datasets(name,version,uri,schema,created_at) VALUES(?,?,?,?,datetime('now'))",
                 (name, version, uri, json.dumps(schema or {})))
    conn.commit()

def record_run(conn, run_id, model_name, model_version, dataset_name, dataset_version, config=None, metrics=None):
    m = conn.execute("SELECT id FROM models WHERE name=? AND version=?", (model_name, model_version)).fetchone()
    d = conn.execute("SELECT id FROM datasets WHERE name=? AND version=?", (dataset_name, dataset_version)).fetchone()
    conn.execute("INSERT INTO runs(run_id,model_id,dataset_id,config,metrics,created_at) VALUES(?,?,?,?,?,datetime('now'))",
                 (run_id, m["id"] if m else None, d["id"] if d else None, json.dumps(config or {}), json.dumps(metrics or {})))
    conn.commit()
