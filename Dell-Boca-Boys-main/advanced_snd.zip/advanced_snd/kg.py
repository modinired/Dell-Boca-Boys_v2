
import json, re
from .db import connect, init_db
from .utils import now_iso, ValidationError

PID_PATTERNS = {
  "ORCID": r"^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$",
  "DOI": r"^10\.\d{4,9}/[-._;()/:A-Z0-9]+$",
  "ROR": r"^0\w{6}\d{2}$",
  "Lightcast": r"^[A-Za-z0-9_-]+$",
  "USPTO": r"^[A-Z0-9/-]+$"
}

def _validate_pid(pid_type, pid):
    if not pid_type and not pid: return
    pat = PID_PATTERNS.get(pid_type)
    if pat and not re.match(pat, (pid or ""), re.IGNORECASE):
        raise ValidationError(f"Invalid {pid_type} format: {pid}")

def create_node(conn, type_name, label, pid_type=None, pid=None, properties=None):
    _validate_pid(pid_type, pid)
    conn.execute(
        "INSERT OR REPLACE INTO nodes(type,label,pid_type,pid,properties,created_at) VALUES(?,?,?,?,?,?)",
        (type_name, label, pid_type, pid, json.dumps(properties or {}), now_iso())
    )
    conn.commit()
    row = conn.execute(
        "SELECT id FROM nodes WHERE type=? AND label=? AND IFNULL(pid_type,'')=IFNULL(?, '') AND IFNULL(pid,'')=IFNULL(?, '') ORDER BY id DESC LIMIT 1",
        (type_name, label, pid_type, pid)
    ).fetchone()
    return row["id"]

def create_triple(conn, subj_id, pred_name, obj_id, properties=None):
    pred = conn.execute("SELECT id,domain_type,range_type FROM predicates WHERE name=?", (pred_name,)).fetchone()
    if not pred:
        raise ValidationError(f"Unknown predicate: {pred_name}")
    s_type = conn.execute("SELECT type FROM nodes WHERE id=?", (subj_id,)).fetchone()["type"]
    o_type = conn.execute("SELECT type FROM nodes WHERE id=?", (obj_id,)).fetchone()["type"]
    if s_type != pred["domain_type"] or o_type != pred["range_type"]:
        raise ValidationError(f"Type mismatch for predicate {pred_name}: expected {pred['domain_type']}->{pred['range_type']}, got {s_type}->{o_type}")
    conn.execute(
        "INSERT INTO triples(subj,pred,obj,properties,created_at) VALUES(?,?,?,?,?)",
        (subj_id, pred["id"], obj_id, json.dumps(properties or {}), now_iso())
    )
    conn.commit()
    return conn.execute("SELECT last_insert_rowid() as id").fetchone()["id"]

def add_evidence(conn, triple_id, evidence_node_id):
    conn.execute("INSERT INTO evidence(triple_id,evidence_node) VALUES(?,?)", (triple_id, evidence_node_id))
    conn.commit()
