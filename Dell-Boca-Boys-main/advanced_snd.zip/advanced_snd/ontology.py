
import json
from .db import connect, init_db

def add_node_type(conn, name, description=""):
    conn.execute("INSERT OR IGNORE INTO node_types(name,description) VALUES(?,?)", (name, description))
    conn.commit()

def add_predicate(conn, name, domain_type, range_type, properties_schema=None, description=""):
    conn.execute(
        "INSERT OR REPLACE INTO predicates(name,domain_type,range_type,properties_schema,description) VALUES(?,?,?,?,?)",
        (name, domain_type, range_type, json.dumps(properties_schema or {}), description)
    )
    conn.commit()

def list_predicates(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM predicates").fetchall()]
