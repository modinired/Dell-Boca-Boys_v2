
import re
ALIASES = {"ai": "artificial intelligence", "reinforcement learning": "rl"}
def normalize_label(label: str) -> str:
    s = label.strip().lower()
    s = re.sub(r"\s+", " ", s)
    return ALIASES.get(s, s)
