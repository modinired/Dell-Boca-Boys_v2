
# Advanced Skills Intelligence Nexus (Production-Ready)

Features:
- Ontology (node types, predicates with domain/range & edge property schemas)
- Knowledge Graph (nodes with PIDs, labeled triples, evidence links)
- Taxonomy mapping (multi-taxonomy support)
- Exporters to JSON-LD and Neo4j CSV
- Governance/MLOps lineage (models, datasets, runs)
- Ingestion connectors (HTTP stdlib) + extraction interfaces + normalization

See CLI usage in the conversation.
