
import json
from datetime import datetime, timezone

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def sha256(obj) -> str:
    data = json.dumps(obj, sort_keys=True, ensure_ascii=False).encode("utf-8")
    import hashlib
    return hashlib.sha256(data).hexdigest()

class ValidationError(Exception):
    pass
