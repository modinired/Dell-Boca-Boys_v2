
from typing import List, Dict, Any

class NERModel:
    def predict(self, text: str) -> List[Dict[str, Any]]:
        raise NotImplementedError

class RelationModel:
    def predict(self, text: str, entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        raise NotImplementedError
