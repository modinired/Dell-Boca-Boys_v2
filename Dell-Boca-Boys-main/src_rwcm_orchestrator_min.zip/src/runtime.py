
import os, json, hashlib, time
from typing import Dict, Any
from .registry import SchemaRegistry
from .secrets import SecretProvider

class OrchestratorRuntime:
    def __init__(self):
        reg_path = os.getenv("SCHEMA_REGISTRY_PATH", "./schema_registry")
        self.registry = SchemaRegistry(reg_path)
        self.secrets = SecretProvider(os.getenv("LOCAL_SECRETS_PATH","./local_secrets.json"))

    def checksum(self, obj: Dict[str, Any]) -> str:
        return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()

    def validate_event(self, subject: str, payload: Dict[str, Any]):
        self.registry.validate_payload(subject, payload)

    def resolve_secret(self, secret_ref: str) -> str:
        return self.secrets.get(secret_ref)
