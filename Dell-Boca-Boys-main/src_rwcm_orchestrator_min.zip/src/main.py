
from fastapi import FastAPI, HTTPException
from .models import ExecuteWorkflow, ExecuteStep, Reflection
from .runtime import OrchestratorRuntime

app = FastAPI(title="SRC–RWCM Orchestrator", version="1.0.0")
rt = OrchestratorRuntime()

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/execute_workflow")
def execute_workflow(req: ExecuteWorkflow):
    # Example of event validation for a known trigger (optional)
    if req.workflow_id == "WF-FIN-001" and "invoice_uri" in req.trigger_payload:
        try:
            rt.validate_event("ap.invoice.received", req.trigger_payload)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Schema validation failed: {e}")
    # In production: load workflow graph from DB, evaluate next_step_logic, enqueue tasks
    return {"accepted": True, "workflow_id": req.workflow_id}

@app.post("/execute_step")
def execute_step(req: ExecuteStep):
    # In production: dispatch to skill adapter (e.g., SAP, OCR) using runtime_binding & secrets
    # This minimal service acknowledges the step; connectors implemented via skill adapters
    return {"accepted": True, "step_id": req.step_id}

@app.post("/reflection")
def reflection(rec: Reflection):
    # In production: persist to reflection_log and invoke autogenesis pipeline
    # Here we return proposal hash so dedupe/merge can be applied upstream
    hashed = rt.checksum(rec.model_dump())
    return {"recorded": True, "proposal_hash": hashed}
