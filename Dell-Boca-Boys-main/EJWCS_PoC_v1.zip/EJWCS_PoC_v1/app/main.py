from fastapi import FastAPI, HTTPException
from pydantic import ValidationError
from src.models import JobWorkflowSchema
from src.mermaid_generator import to_mermaid
from datetime import datetime
import uuid

app = FastAPI(title="EJWCS PoC API", version="1.0")

DB = {}  # simple in-memory store for PoC

@app.post("/extract", response_model=dict)
def extract(workflow: JobWorkflowSchema):
    # In a real system, the LLM extraction happens upstream; here we just validate & store
    try:
        _ = JobWorkflowSchema.model_validate(workflow.model_dump())
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))
    wid = str(uuid.uuid4())
    DB[wid] = {"json": workflow.model_dump(), "created_at": datetime.utcnow().isoformat()}
    return {"workflow_id": wid}

@app.get("/workflow/{wid}")
def get_workflow(wid: str):
    if wid not in DB:
        raise HTTPException(404, "Not found")
    return DB[wid]["json"]

@app.get("/workflow/{wid}/mermaid")
def get_mermaid(wid: str):
    if wid not in DB:
        raise HTTPException(404, "Not found")
    wf = JobWorkflowSchema.model_validate(DB[wid]["json"])
    return {"mermaid": to_mermaid(wf)}
