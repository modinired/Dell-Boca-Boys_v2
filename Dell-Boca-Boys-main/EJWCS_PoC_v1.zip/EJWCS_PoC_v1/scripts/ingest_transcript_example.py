"""
Example: validate an already-extracted workflow JSON and emit Mermaid.
"""
from src.models import JobWorkflowSchema, TaskObject, ConditionalLogic, ConditionalBranch
from src.mermaid_generator import to_mermaid
import json

def example():
    wf = JobWorkflowSchema(
        workflow_name="GL Reconciliation",
        tasks=[
            TaskObject(
                task_id="t1",
                task_description="Export trial balance from NetSuite",
                role_owner="Staff Accountant",
                tools=["NetSuite"],
                precedes_tasks=["t2"],
            ),
            TaskObject(
                task_id="t2",
                task_description="Reconcile GL accounts in Excel",
                role_owner="Staff Accountant",
                tools=["Excel"],
                dependencies=["t1"],
                conditional_logic=ConditionalLogic(
                    gateway="XOR",
                    condition_text="Variance > $1000?",
                    branches=[
                        ConditionalBranch(label="> $1000", next_task_id="t3"),
                        ConditionalBranch(label="≤ $1000", next_task_id="t4"),
                    ],
                ),
            ),
            TaskObject(
                task_id="t3",
                task_description="Escalate to Manager for review",
                role_owner="Manager",
                dependencies=["t2"],
            ),
            TaskObject(
                task_id="t4",
                task_description="Mark account reconciled",
                role_owner="Staff Accountant",
                dependencies=["t2"],
            ),
        ],
    )
    print("Validated JSON:\n", json.dumps(wf.model_dump(), indent=2, ensure_ascii=False))
    print("\nMermaid:\n", to_mermaid(wf))

if __name__ == "__main__":
    example()
