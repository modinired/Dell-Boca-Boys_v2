# EJWCS PoC v1

This package contains:
- Tech spec (Markdown)
- Pydantic models for EJWCS
- Mermaid generator utility
- FastAPI scaffold to store/retrieve workflows and render Mermaid
- WORKFLOW_EXTRACTOR prompts (system + repair)
- Example script demonstrating validation + Mermaid output

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Run example
python scripts/ingest_transcript_example.py

# Run API
uvicorn app.main:app --reload
```

## Contents
- `EJWCS_Tech_Spec_v1.0.md`
- `src/models.py`
- `src/mermaid_generator.py`
- `app/main.py`
- `prompts/workflow_extractor_system.txt`
- `prompts/workflow_extractor_repair.txt`
- `scripts/ingest_transcript_example.py`
- `requirements.txt`
