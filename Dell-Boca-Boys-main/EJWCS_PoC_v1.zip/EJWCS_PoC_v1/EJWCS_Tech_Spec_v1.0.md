# Enhanced Job Workflow Capture & Synthesis Framework (EJWCS)

**Version:** 1.0  
**Owner:** CESAR (Prompt & Automation Specialist)  
**Purpose:** Convert unstructured occupational knowledge into standardized, machine-readable workflow data mapped to ESCO/O*NET and rendered as Diagrams-as-Code (Mermaid).

---

## 0) Executive Summary
EJWCS is a schema-first pipeline that ingests rich sources (SME interviews, SOPs, job posts, videos), extracts atomic tasks with dependencies/conditions via an LLM constrained by Pydantic models, standardizes skills/knowledge against ESCO & O*NET, and synthesizes Mermaid diagrams. A validation loop enforces structural and semantic fidelity to BPMN-like rules. The Q1/Q2 PoC targets Accounting (Staff Accountant).

---

## 1) System Goals & Non-Goals
**Goals:**
- Deterministic JSON outputs that pass strict validation.
- Dual taxonomy mapping (ESCO Knowledge/Skill pillars; O*NET Occupation).
- Mermaid generation faithful to BPMN semantics (sequence, XOR/OR/AND gateways).
- Human-in-the-loop verification with measurable KPIs (schema compliance, semantic accuracy).

**Non-Goals (v1):**
- Full BPMN 2.0 XML export (optional v2).
- Real-time meeting capture (batch-first).
- Auto-remediation of conflicting SME statements (flag w/ confidence, human validate).

---

## 2) High-Level Architecture
```
┌─────────────────────┐     ┌──────────────────────┐     ┌──────────────────────┐
│ Capture/Ingestion   │ --> │ Extraction (LLM+Pyd) │ --> │ Standardization       │
│  - Azure Speech     │     │  - WORKFLOW_EXTRACTOR│     │  - ESCO/O*NET Mapper  │
│  - Parsers (PDF/HTML│     │  - JSON Validator    │     │  - Quality Scoring    │
└─────────┬───────────┘     └───────────┬──────────┘     └──────────┬──────────┘
          │                               │                          │
          ▼                               ▼                          ▼
      Clean Transcript                Validated JSON           Mapped JSON (IDs)
          │                               │                          │
          └──────────────► Persistence (Postgres + S3/Blob) ◄────────┘
                                       │
                                       ▼
                              Synthesis & Visualization
                               - Mermaid Generator
                               - Audit & Review Module
```

**Tech Stack (reference):** Python 3.11, FastAPI, Pydantic v2, Postgres 15, SQLAlchemy, Celery/RQ, Redis, Azure AI Speech (Batch), Azure Storage/S3, LangChain (optional), Docker, Terraform.

---

## 3) Data Contracts (Pydantic Models)

### 3.1 Core Schemas
```python
from typing import List, Optional, Literal, Dict
from pydantic import BaseModel, Field
from uuid import uuid4

GatewayType = Literal["XOR", "OR", "AND"]

class ConditionalBranch(BaseModel):
    label: str = Field(..., description="Human-readable condition label")
    next_task_id: str = Field(..., description="Task ID to jump to if condition true")

class ConditionalLogic(BaseModel):
    gateway: GatewayType = Field(..., description="Type of decision semantics")
    condition_text: Optional[str] = Field(None, description="Free-text logical statement")
    branches: List[ConditionalBranch] = Field(..., min_items=2)

class KnowledgeTag(BaseModel):
    name: str
    esco_id: Optional[str] = None

class SkillTag(BaseModel):
    name: str
    esco_id: Optional[str] = None

class TaskObject(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid4()))
    task_description: str
    role_owner: Optional[str] = Field(None, description="Occupation label; map to O*NET.")
    onet_id: Optional[str] = None
    precedes_tasks: List[str] = Field(default_factory=list)
    dependencies: List[str] = Field(default_factory=list)
    conditional_logic: Optional[ConditionalLogic] = None
    required_knowledge: List[KnowledgeTag] = Field(default_factory=list)
    required_skill_tags: List[SkillTag] = Field(default_factory=list)
    tools: List[str] = Field(default_factory=list)
    frequency: Optional[str] = None
    estimated_time_min: Optional[int] = None
    confidence: Optional[float] = Field(None, ge=0, le=1)

class JobWorkflowSchema(BaseModel):
    workflow_name: str
    role: Optional[str] = None
    seniority: Optional[str] = None
    tasks: List[TaskObject] = Field(..., min_items=1)
    metadata: Dict[str, str] = Field(default_factory=dict)
```

### 3.2 Source Quality & Provenance
```python
class SourceQuality(BaseModel):
    source_url: str
    publication_date: Optional[str] = None  # ISO8601
    author_credentials: Optional[str] = None
    company_size: Optional[str] = None
    industry: Optional[str] = None
    quality_score: Optional[float] = Field(None, ge=0, le=1)
    reasons: List[str] = Field(default_factory=list)
```

### 3.3 Storage DTOs
```python
class StoredWorkflow(BaseModel):
    workflow_id: str
    json_payload: JobWorkflowSchema
    mermaid_text: str
    esco_version: str
    onet_version: str
    created_at: str
    updated_at: str
```

---

## 4) Prompt Design: WORKFLOW_EXTRACTOR (Schema-First)

### 4.1 System Instruction (excerpt)
```
You are the EJWCS WORKFLOW_EXTRACTOR. Output a SINGLE JSON object that VALIDATES against the provided Pydantic models.
- Do NOT invent fields. Include all keys; use null when unknown.
- Capture atomic tasks; infer dependencies and conditions from sequencing language.
- Use role_owner from diarized speaker labels where possible.
- Use conditional_logic with gateway = "XOR" unless transcript clearly implies OR/AND.
- Populate required_knowledge/required_skill_tags with plain names; mapper will append IDs.
- Never include commentary or markdown—only JSON.
```

### 4.2 Input Envelope
```json
{
  "transcript": "<clean, diarized text with timestamps and speakers>",
  "hints": {"domain": "Accounting", "workflow_name": "Monthly Financial Close"},
  "schema": "<verbatim Pydantic definitions above>"
}
```

### 4.3 Semantic Mapping Rules (operational bullets)
- Phrases like "before X, do Y" ⇒ Y in dependencies of X.
- "If <condition>, do A; else, do B" ⇒ conditional_logic.gateway = "XOR", create branches labeled.
- Repetitive periodic language (daily/weekly/monthly) ⇒ frequency on the relevant tasks.
- Time mentions ⇒ estimated_time_min as integer when explicit.

### 4.4 JSON Rejection/Re-prompt Loop
- Validate with JobWorkflowSchema.model_validate_json.
- On failure: capture validation errors, auto-generate a terse repair prompt with exact error messages and the last invalid JSON, instruct model to fix only those fields.

---

## 5) Ingestion & Pre-processing

### 5.1 SME Capture (DACUM-based)
- Interview script captures duties → tasks → performance criteria → tools → knowledge/skills → conditions.
- Require consent + PII redaction pass (names, emails, identifiers).

### 5.2 Transcription (Azure AI Speech Batch)
- Large files (≤1GB), diarization, word-level timestamps.
- Output JSON aligned to segments: [ {speaker, start, end, text}, ... ].

### 5.3 Parsers
- PDF/Docx/HTML normalizer; YouTube/Vimeo transcript fetch (when available) else Whisper small for ad-hoc.
- Forum ingestion (Reddit API/PRAW) with thread summarization flags ("How do I…", "Process for …").

---

## 6) Standardization Layer (ESCO/O*NET Mapper)

### 6.1 Mapping Strategy
- ESCO: map required_knowledge and required_skill_tags strings → ESCO concept IDs.
- O*NET: map role_owner to occupation code; optionally map skills via crosswalks.

### 6.2 Implementation Outline
- Local synonym dictionary + embeddings search over cached ESCO/O*NET index.
- Confidence score per mapping; thresholded acceptance; low-confidence → human review queue.
- Versioning: persist dataset versions used for every mapping run.

---

## 7) Synthesis: Mermaid Generator

### 7.1 Conversion Rules
- Node label: task_id[ {role}: {short desc} ] (truncate description to ≤60 chars).
- Edges: For each task, for every successor in precedes_tasks, add `A --> B`.
- Dependencies: Render fan-in with an implicit merge note if multiple dependencies converge.
- Conditional: Insert decision node dX{condition_text or gateway} with labeled edges `-- label --> next_task`.

### 7.2 Pseudocode
```python
def to_mermaid(workflow: JobWorkflowSchema) -> str:
    lines = ["flowchart TD"]
    for t in workflow.tasks:
        role = t.role_owner or "role?"
        short = (t.task_description[:57] + "…") if len(t.task_description) > 60 else t.task_description
        lines.append(f"{t.task_id}[{role}: {short}]")
        if t.conditional_logic:
            d_id = f"d_{t.task_id}"
            label = t.conditional_logic.condition_text or t.conditional_logic.gateway
            lines.append(f"{d_id}{{{label}}}")
            lines.append(f"{t.task_id} --> {d_id}")
            for br in t.conditional_logic.branches:
                lines.append(f"{d_id} -- {br.label} --> {br.next_task_id}")
        for succ in t.precedes_tasks:
            lines.append(f"{t.task_id} --> {succ}")
    return "\n".join(lines)
```

---

## 8) Persistence & APIs

### 8.1 Database (Postgres) DDL (excerpt)
```sql
CREATE TABLE workflow (
  id UUID PRIMARY KEY,
  workflow_name TEXT NOT NULL,
  role TEXT,
  seniority TEXT,
  json_payload JSONB NOT NULL,
  mermaid_text TEXT NOT NULL,
  esco_version TEXT,
  onet_version TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE provenance (
  workflow_id UUID REFERENCES workflow(id) ON DELETE CASCADE,
  source_url TEXT,
  publication_date DATE,
  author_credentials TEXT,
  company_size TEXT,
  industry TEXT,
  quality_score REAL,
  reasons TEXT[]
);

CREATE INDEX idx_workflow_name ON workflow (workflow_name);
CREATE INDEX idx_json_gin ON workflow USING GIN (json_payload);
```

### 8.2 Service Endpoints (FastAPI)
- POST /ingest/transcript → returns transcript_id
- POST /extract (transcript_id, hints) → returns workflow_id
- GET /workflow/{id} → JSON payload
- GET /workflow/{id}/mermaid → Mermaid text
- POST /map-taxonomy/{id} → updated JSON with ESCO/O*NET
- POST /validate/{id} → validation report (schema + semantic checks)

---

## 9) Validation & QA

### 9.1 Automated
- Pydantic validation (100% required).
- Mermaid lint (no dangling edges, all nodes referenced).
- Rule checks: XOR gateway must have ≥2 branches; every dependency must exist.

### 9.2 Human-in-the-loop
- SME Review Form (per task): sequence correctness, role ownership, condition semantics, skill/knowledge relevance (Likert + comments).
- Acceptance criteria: ≥95% schema compliance; ≥90% SME agreement on conditional nodes; <5% hallucinated fields.

---

## 10) Accounting PoC Scope (v1)
- Workflows: GL Reconciliation, Monthly Close, Audit Support, AP 3-way Match, AR Cash Application.
- Artifacts per workflow: Validated JSON, Mermaid text, source provenance, mapping report, reviewer sign-off.

Success Metrics: schema compliance, semantic accuracy, mapping coverage, visualization errors = 0.

---

## 11) Risk & Mitigation
- LLM JSON drift: schema-in-prompt + validator loop + temperature ≤0.2.
- Ambiguous transcripts: diarization mandate + DACUM + follow-up prompts for missing fields.
- Taxonomy mismatch: synonym lists + embeddings search + human thresholding.
- PII/Compliance: redaction pipeline; source allowlist; secure blob storage; audit logs.

---

## 12) Delivery Plan & Timeline (Q1/Q2)
- T0–T4 Foundation: SME recruitment, Azure Speech config, schema freeze, baseline parsers.
- T5–T8 Agent Calibration: prompt iterations, error-driven repair loop, first valid GL Recon.
- T9–T12 Synthesis & Audit: 5–8 workflows, mapping, Mermaid exports, collaboration demo.

---

## 13) Implementation Backlog (First 10 Issues)
1. Create Pydantic packages and JSON schema export.
2. Implement transcript normalizer + diarization aligner.
3. Build extractor service with validation/retry loop.
4. Add ESCO/O*NET lightweight indexer + embeddings cache.
5. Write Mermaid generator + linter.
6. Postgres schema + migration scripts.
7. FastAPI endpoints + auth (JWT/OIDC).
8. Provenance scoring (recency × credentials × redundancy).
9. SME review portal (streamlit/Next.js) with Mermaid embed.
10. CI tests for schema, mapping, mermaid integrity.

---

## 14) Sample End-to-End (Mini Example)
Input (excerpt): S1 (Accountant): "Export trial balance from NetSuite, reconcile each GL; if variance > $1000, escalate to Manager; else mark reconciled."

Extractor Output (abridged):
```json
{
  "workflow_name": "GL Reconciliation",
  "tasks": [
    {"task_id": "t1","task_description": "Export trial balance from NetSuite","role_owner": "Staff Accountant","tools": ["NetSuite"],"precedes_tasks": ["t2"]},
    {"task_id": "t2","task_description": "Reconcile GL accounts in Excel","role_owner": "Staff Accountant","tools": ["Excel"],"conditional_logic": {"gateway": "XOR","condition_text": "Variance > $1000?","branches": [{"label": "> $1000","next_task_id": "t3"},{"label": "≤ $1000","next_task_id": "t4"}]},"dependencies": ["t1"]},
    {"task_id": "t3","task_description": "Escalate to Manager for review","role_owner": "Manager","dependencies": ["t2"]},
    {"task_id": "t4","task_description": "Mark account reconciled","role_owner": "Staff Accountant","dependencies": ["t2"]}
  ]
}
```

Mermaid (generated):
```
flowchart TD
 t1[Staff Accountant: Export trial balance from NetSuite]
 t2[Staff Accountant: Reconcile GL accounts in Excel]
 d_t2{Variance > $1000?}
 t1 --> t2
 t2 --> d_t2
 d_t2 -- > $1000 --> t3
 d_t2 -- ≤ $1000 --> t4
 t3[Manager: Escalate to Manager for review]
 t4[Staff Accountant: Mark account reconciled]
```

---

## 15) SME Validation Questionnaire (excerpt)
- Does each task have the correct role_owner?
- Are dependencies and precedes_tasks accurate for your process?
- For each decision, is the gateway type and branching correct?
- Are skills/knowledge tags complete and relevant?
- Time/frequency reasonable? What ranges are typical?

---

## 16) Security & Compliance
- Data minimization, PII redaction, encrypted storage (AES-256 at rest), TLS in transit.
- Role-based access control; audit trail on every mutation.
- Source license tracking; robots/ToS compliance for scraping.

---

## 17) Cost & Scaling Notes (PoC)
- Azure Speech Batch dominates variable cost; batch jobs scheduled overnight.
- GPU usage optional (local Whisper) for non-critical sources.
- Caching: de-duplicate near-identical sources via MinHash/SimHash before extraction.

---

## 18) Future Work (v2+)
- BPMN 2.0 XML export; round-trip edit to JSON.
- Active learning on reviewer feedback to auto-correct extraction.
- Automation opportunity scoring per task (repetition × structure × tool APIs).
- Cross-role overlap analytics for org design.

---

## 19) Definition of Done (PoC)
- 5–8 Accounting workflows with: validated JSON, Mermaid, provenance, mapping.
- Dashboard with search over tasks/skills; export endpoints live.
- External SME sign-off ≥90% agreement on decision semantics.

---

End of Spec (v1.0)
