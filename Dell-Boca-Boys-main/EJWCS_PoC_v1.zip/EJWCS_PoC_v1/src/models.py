from typing import List, Optional, Literal, Dict
from pydantic import BaseModel, Field
from uuid import uuid4

GatewayType = Literal["XOR", "OR", "AND"]

class ConditionalBranch(BaseModel):
    label: str = Field(..., description="Human-readable condition label")
    next_task_id: str = Field(..., description="Task ID to jump to if condition true")

class ConditionalLogic(BaseModel):
    gateway: GatewayType = Field(..., description="Type of decision semantics")
    condition_text: Optional[str] = Field(None, description="Free-text logical statement")
    branches: List[ConditionalBranch] = Field(..., min_items=2)

class KnowledgeTag(BaseModel):
    name: str
    esco_id: Optional[str] = None

class SkillTag(BaseModel):
    name: str
    esco_id: Optional[str] = None

class TaskObject(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid4()))
    task_description: str
    role_owner: Optional[str] = Field(None, description="Occupation label; map to O*NET.")
    onet_id: Optional[str] = None
    precedes_tasks: List[str] = Field(default_factory=list)
    dependencies: List[str] = Field(default_factory=list)
    conditional_logic: Optional[ConditionalLogic] = None
    required_knowledge: List[KnowledgeTag] = Field(default_factory=list)
    required_skill_tags: List[SkillTag] = Field(default_factory=list)
    tools: List[str] = Field(default_factory=list)
    frequency: Optional[str] = None
    estimated_time_min: Optional[int] = None
    confidence: Optional[float] = Field(None, ge=0, le=1)

class JobWorkflowSchema(BaseModel):
    workflow_name: str
    role: Optional[str] = None
    seniority: Optional[str] = None
    tasks: List[TaskObject] = Field(..., min_items=1)
    metadata: Dict[str, str] = Field(default_factory=dict)
