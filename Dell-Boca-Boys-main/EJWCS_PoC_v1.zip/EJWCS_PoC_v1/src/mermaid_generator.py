from typing import List
from .models import JobWorkflowSchema

def to_mermaid(workflow: JobWorkflowSchema) -> str:
    lines = ["flowchart TD"]
    for t in workflow.tasks:
        role = t.role_owner or "role?"
        short = (t.task_description[:57] + "…") if len(t.task_description) > 60 else t.task_description
        # Square brackets: node
        lines.append(f"{t.task_id}[{role}: {short}]")
        # Decision gateway
        if t.conditional_logic:
            d_id = f"d_{t.task_id}"
            label = t.conditional_logic.condition_text or t.conditional_logic.gateway
            lines.append(f"{d_id}{{{label}}}")
            lines.append(f"{t.task_id} --> {d_id}")
            for br in t.conditional_logic.branches:
                lines.append(f"{d_id} -- {br.label} --> {br.next_task_id}")
        # Sequence edges
        for succ in t.precedes_tasks:
            lines.append(f"{t.task_id} --> {succ}")
    return "\n".join(lines)
