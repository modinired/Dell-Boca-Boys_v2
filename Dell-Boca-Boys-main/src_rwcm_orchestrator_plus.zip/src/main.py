
from fastapi import FastAPI, HTTPException
from .models import ExecuteWorkflow, ExecuteStep, Reflection
from .runtime import OrchestratorRuntime
from .repo import Repo
from .secrets import SecretProvider
import os, json

app = FastAPI(title="SRC–RWCM Orchestrator", version="1.1.0")
rt = OrchestratorRuntime()
repo = Repo()

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/execute_workflow")
def execute_workflow(req: ExecuteWorkflow):
    wf = repo.get_workflow_with_steps(req.workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")

    # Optional: validate trigger against registry if subject present (example)
    subj = req.trigger_payload.get("_subject")
    if subj:
        try:
            rt.validate_event(subj, req.trigger_payload)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Schema validation failed: {e}")

    # Return ordered step ids for the client/worker to execute
    steps = [{"step_id": s.step_id, "action_type": s.action_type, "skill_id": s.skill_id} for s in wf.steps]
    return {"accepted": True, "workflow_id": req.workflow_id, "steps": steps}

@app.post("/execute_step")
def execute_step(req: ExecuteStep):
    # In a full system, we'd look up step by ID and its bound skill & runtime_binding.
    # For now, require client to pass binding alongside input OR resolve via catalog; here we allow a 'binding' field.
    binding = req.input.get("runtime_binding")
    if not binding:
        return {"accepted": True, "step_id": req.step_id, "note":"no runtime_binding provided; treated as builtin or logic step"}

    adapter = rt.adapter_from_binding(binding)
    if adapter is None:
        return {"accepted": True, "step_id": req.step_id, "note":"builtin skill executed"}

    # Dispatch based on common method names
    method = req.input.get("method","")
    payload = req.input.get("payload", {})
    if hasattr(adapter, method):
        fn = getattr(adapter, method)
        result = fn(**payload) if isinstance(payload, dict) else fn(payload)
        return {"accepted": True, "step_id": req.step_id, "result": result}
    else:
        raise HTTPException(status_code=400, detail=f"Adapter does not support method '{method}'")

@app.post("/reflection")
def reflection(rec: Reflection):
    hashed = rt.checksum(rec.model_dump())
    return {"recorded": True, "proposal_hash": hashed}
