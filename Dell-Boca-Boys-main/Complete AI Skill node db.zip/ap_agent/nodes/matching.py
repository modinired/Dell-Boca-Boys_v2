
from __future__ import annotations
from typing import Dict, Any, List
import os, csv

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

def _load_po(po_id: str) -> dict|None:
    path = os.path.join(DATA_DIR, "pos.csv")
    if not os.path.exists(path): 
        return None
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    lines = []
    supplier_id = None
    for r in rows:
        if r["po_id"] == po_id:
            lines.append({
                "po_line_id": r["po_line_id"],
                "description": r["description"],
                "qty": float(r["qty"]),
                "unit_price": float(r["unit_price"]),
                "currency": r.get("currency","USD")
            })
            supplier_id = r.get("supplier_id")
    if not lines:
        return None
    return {"po_id": po_id, "supplier_id": supplier_id, "lines": lines}

def _load_grns(po_id: str) -> list[dict]:
    path = os.path.join(DATA_DIR, "grns.csv")
    if not os.path.exists(path): 
        return []
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    grns = []
    for r in rows:
        if r["po_id"] == po_id:
            grns.append({
                "gr_id": r["gr_id"],
                "po_id": po_id,
                "lines": [{"po_line_id": r["po_line_id"], "qty_received": float(r["qty_received"])}]
            })
    return grns

def retrieve_po_gr(ctx: Dict[str, Any]) -> Dict[str, Any]:
    inv = ctx["invoice"]
    po = _load_po(inv.get("po_id") or "")
    grns = _load_grns(inv.get("po_id") or "")
    ctx["po"] = po
    ctx["grns"] = grns
    return ctx

def perform_match(ctx: Dict[str, Any]) -> Dict[str, Any]:
    inv = ctx["invoice"]
    po = ctx.get("po")
    grns = ctx.get("grns",[])
    # default: 2-way if no GRNs and invoice is SERVICES
    required_gr = (inv.get("invoice_type","GOODS")=="GOODS")
    report = {"status":"match","variances":[]}
    if po is None:
        report["status"] = "exception"
        report["variances"].append({"type":"NO_PO","msg":"PO not found"})
        ctx["match_report"] = report
        return ctx
    # line-by-line comparison
    po_map = {l["po_line_id"]: l for l in po["lines"]}
    gr_map = {}
    for g in grns:
        for gl in g["lines"]:
            gr_map[gl["po_line_id"]] = gr_map.get(gl["po_line_id"],0)+gl["qty_received"]
    for li in inv["lines"]:
        po_l = po_map.get(li.get("po_line_id"))
        if not po_l:
            report["status"] = "exception"
            report["variances"].append({"type":"PO_LINE_MISSING","line":li["line_id"]})
            continue
        # price tolerance 2%
        price_delta = abs(li["unit_price"] - po_l["unit_price"])
        if price_delta > po_l["unit_price"]*0.02:
            report["status"] = "tolerance" if report["status"]=="match" else report["status"]
            report["variances"].append({"type":"PRICE","line":li["line_id"],"expected":po_l["unit_price"],"actual":li["unit_price"]})
        # quantity check (3-way if required)
        if required_gr:
            received = gr_map.get(po_l["po_line_id"],0.0)
            if li["qty"] > received + 1e-6:
                report["status"] = "exception"
                report["variances"].append({"type":"QTY_UNRECEIVED","line":li["line_id"],"invoiced":li["qty"],"received":received})
    ctx["match_report"] = report
    return ctx
