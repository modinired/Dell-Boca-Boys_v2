
from __future__ import annotations
from typing import Dict, Any
import zipfile, os, io

def bundle(ctx: Dict[str, Any]) -> Dict[str, Any]:
    trace = ctx.get("trace_id","trace")
    zip_path = f"/mnt/data/ap_agent/audit_{trace}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        # telemetry
        if "telemetry" in ctx:
            import json
            z.writestr("telemetry.json", json.dumps(ctx["telemetry"], indent=2))
        if "match_report" in ctx:
            import json
            z.writestr("match_report.json", json.dumps(ctx["match_report"], indent=2))
        if "approval_route" in ctx:
            import json
            z.writestr("approval_route.json", json.dumps(ctx["approval_route"], indent=2))
        if "nacha_file" in ctx:
            z.writestr("nacha.ach", ctx["nacha_file"]["file_content"])
    ctx["zip_path"] = zip_path
    return ctx
