
from __future__ import annotations
from typing import Dict, Any
import csv, os

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

def load_vendors() -> dict:
    path = os.path.join(DATA_DIR, "vendor_master.csv")
    vendors = {}
    if os.path.exists(path):
        with open(path, newline="") as f:
            for row in csv.DictReader(f):
                vendors[row["name"].strip().lower()] = row
    return vendors

def lookup(ctx: Dict[str, Any]) -> Dict[str, Any]:
    inv = ctx["invoice"]
    vendors = load_vendors()
    v = vendors.get(inv["supplier_name"].strip().lower())
    if v:
        ctx["vendor"] = {
            "vendor_id": v["vendor_id"],
            "name": v["name"],
            "country": v.get("country","US"),
            "tax_form": v.get("tax_form") or None,
            "tin": v.get("tin") or None,
            "ofac_status": "unknown",
            "ach": {
                "routing": v.get("routing",""),
                "account": v.get("account",""),
                "sec": v.get("sec","CCD") or "CCD"
            }
        }
    else:
        # auto-provision minimal vendor; real systems would block until onboarding
        ctx["vendor"] = {
            "vendor_id": "NEW-"+inv["supplier_name"].upper().replace(" ","-"),
            "name": inv["supplier_name"],
            "country": "US",
            "ofac_status": "unknown",
            "ach": None
        }
    return ctx
