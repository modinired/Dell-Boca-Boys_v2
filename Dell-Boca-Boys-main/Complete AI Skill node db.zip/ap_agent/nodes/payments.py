
from __future__ import annotations
from typing import Dict, Any, List
from datetime import datetime
import math

def _pad(s, length, fill=" "):
    s = str(s)[:length]
    return s + (fill*(length-len(s)))

def _num(n, length):
    s = f"{int(round(float(n)*100))}"  # cents
    return s.rjust(length, "0")

def _routing_check(r):
    digits = [int(c) for c in r if c.isdigit()]
    if len(digits)!=9: 
        return False
    checksum = (3*(digits[0]+digits[3]+digits[6]) + 7*(digits[1]+digits[4]+digits[7]) + (digits[2]+digits[5]+digits[8])) % 10
    return checksum == 0

def generate_nacha(ctx: Dict[str, Any]) -> Dict[str, Any]:
    entries = ctx["payment_entries"]
    # Simple single-batch file (CCD) format - 94 char lines
    now = datetime.utcnow()
    file_id = now.strftime("%y%j")
    routing = "091000019"  # example ODFI routing (passes checksum)
    immediate_dest = routing
    immediate_origin = "123456780"  # example
    lines: List[str] = []

    # File Header (1)
    line = "1" + \
        _pad(immediate_dest,10) + \
        _pad(immediate_origin,10) + \
        now.strftime("%y%m%d") + now.strftime("%H%M") + \
        "A" + "094" + _pad("1",10) + _pad("AP AGENT",23) + _pad("BANK",23) + now.strftime("%y%j") + _pad("",8)
    lines.append(line[:94])

    # Batch Header (5)
    service_class = "200"  # credits only
    company_name = _pad("AP AGENT",16)
    company_id = "123456789"
    sec = "CCD"
    entry_desc = _pad("VENDOR PAY",10)
    debit_credit_date = now.strftime("%y%m%d")
    odfi_id = routing[:8]
    batch_header = "5"+service_class+company_name+_pad("",20)+company_id+sec+entry_desc+_pad("",6)+debit_credit_date+_pad("",3)+_pad("",1)+_pad("",3)+odfi_id+"0001"
    lines.append(batch_header[:94])

    trace_seq = 1
    entry_hash = 0
    total_cents = 0

    for e in entries:
        assert _routing_check(e["routing"]), f"Invalid routing: {e['routing']}"
        # Entry Detail (6)
        # CCD credit to checking = 22
        tran_code = "22"
        dfia = e["routing"]
        dfia_acct = _pad(e["account"],17)
        amount_cents = int(round(e["amount"]*100))
        ident = _pad(e["invoice_id"],15)
        name = _pad(e["vendor_id"],22)
        trace = odfi_id + str(trace_seq).rjust(7,"0")
        entry = "6"+tran_code+dfia+dfia_acct+str(amount_cents).rjust(10,"0")+ident+name+_pad("",2)+trace
        lines.append(entry[:94])
        entry_hash += int(dfia[:8])
        total_cents += amount_cents
        trace_seq += 1

    # Batch Control (8)
    entry_count = len(entries)
    batch_control = "8"+service_class+\
        str(entry_count).rjust(6,"0")+\
        str(entry_hash % (10**10)).rjust(10,"0")+\
        str(total_cents).rjust(12,"0")+\
        str(0).rjust(12,"0")+ \
        company_id + _pad("",19) + odfi_id + "0001"
    lines.append(batch_control[:94])

    # File Control (9)
    block_count = math.ceil((len(lines)+1)/10)  # +1 for file control
    file_control = "9"+str(1).rjust(6,"0")+str(block_count).rjust(6,"0")+str(entry_count).rjust(8,"0")+str(entry_hash % (10**10)).rjust(10,"0")+str(total_cents).rjust(12,"0")+str(0).rjust(12,"0")+_pad("",39)
    lines.append(file_control[:94])

    content = "\n".join(lines)
    ctx["nacha_file"] = {"file_content": content, "control_totals":{"entries":entry_count,"amount":total_cents/100}}
    return ctx
