
from __future__ import annotations
from typing import Dict, Any

def reconcile(ctx: Dict[str, Any]) -> Dict[str, Any]:
    nacha = ctx["nacha_file"]
    invoices = {i["invoice_id"]: i for i in ctx["invoices"]}
    amount_sum = 0.0
    for e in ctx["payment_entries"]:
        inv = invoices.get(e["invoice_id"])
        if inv:
            inv["paid"] = True
            amount_sum += e["amount"]
    ctx["reconciliation_report"] = {"paid_total": round(amount_sum,2), "count": len(ctx["payment_entries"])}
    return ctx
