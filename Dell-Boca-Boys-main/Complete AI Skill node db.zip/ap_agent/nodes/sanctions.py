
from __future__ import annotations
from typing import Dict, Any
import csv, os

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

def sanctions_screen(ctx: Dict[str, Any]) -> Dict[str, Any]:
    vendor = ctx["vendor"]
    path = os.path.join(DATA_DIR, "sanctions_list.csv")
    names = set()
    if os.path.exists(path):
        with open(path, newline="") as f:
            for row in csv.DictReader(f):
                names.add(row["name"].strip().lower())
    target = vendor["name"].strip().lower()
    if target in names:
        vendor["ofac_status"] = "fail"
    else:
        vendor["ofac_status"] = "pass"
    ctx["vendor"] = vendor
    return ctx
