
from __future__ import annotations
from typing import Dict, Any
import os, yaml

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

def enforce_sod(ctx: Dict[str, Any]) -> Dict[str, Any]:
    inv = ctx["invoice"]
    amt = inv["amount"]
    path = os.path.join(DATA_DIR, "approval_matrix.yaml")
    with open(path) as f:
        matrix = yaml.safe_load(f)
    approvers = []
    for r in matrix["rules"]:
        if r["min"] <= amt <= r["max"]:
            approvers = r["approvers"]
            break
    route = {"required": approvers, "status":"pending"}
    ctx["approval_route"] = route
    return ctx
