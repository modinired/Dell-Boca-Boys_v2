
from __future__ import annotations
from typing import Dict, Any
from datetime import date

def validate_invoice_basics(ctx: Dict[str, Any]) -> Dict[str, Any]:
    inv = ctx["invoice"]
    issues = []
    # basic normalization
    if inv["invoice_date"] > inv["due_date"]:
        issues.append("invoice_date_after_due_date")
    if inv.get("currency") is None:
        inv["currency"] = "USD"
    if not inv.get("lines"):
        issues.append("no_lines")
    # calculate tax if not provided
    if "tax_amount" not in inv:
        inv["tax_amount"] = round(sum(l["qty"]*l["unit_price"]*l.get("tax_rate",0.0) for l in inv["lines"]),2)
    ctx["invoice"] = inv
    ctx["issues"] = issues
    return ctx
