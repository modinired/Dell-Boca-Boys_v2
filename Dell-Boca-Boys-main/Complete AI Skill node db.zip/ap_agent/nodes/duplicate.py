
from __future__ import annotations
from typing import Dict, Any
import hashlib

_seen = set()

def _fingerprint(inv: dict) -> str:
    key = f"{inv['supplier_name']}|{inv['invoice_id']}|{inv['invoice_date']}|{inv['amount']}"
    return hashlib.sha256(key.encode()).hexdigest()

def detect_duplicates(ctx: Dict[str, Any]) -> Dict[str, Any]:
    inv = ctx["invoice"]
    fp = _fingerprint(inv)
    dup = fp in _seen
    if not dup:
        _seen.add(fp)
    ctx["dup_flags"] = [{"type":"DUPLICATE","present":True}] if dup else []
    return ctx
