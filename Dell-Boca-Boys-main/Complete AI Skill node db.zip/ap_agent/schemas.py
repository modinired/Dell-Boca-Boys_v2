
from __future__ import annotations
from pydantic import BaseModel, Field, field_validator
from typing import List, Optional, Literal, Dict
from datetime import date, datetime

Currency = Literal["USD","EUR","GBP","JPY","AUD","CAD"]
InvoiceType = Literal["GOODS","SERVICES"]
SecCode = Literal["PPD","CCD","CTX"]

class InvoiceLine(BaseModel):
    line_id: str
    description: str
    qty: float = Field(ge=0)
    unit_price: float = Field(ge=0)
    currency: Currency = "USD"
    tax_rate: float = 0.0  # decimal
    po_line_id: Optional[str] = None

class Invoice(BaseModel):
    invoice_id: str
    supplier_name: str
    supplier_id: Optional[str] = None
    invoice_date: date
    due_date: date
    terms: str = "Net 30"
    currency: Currency = "USD"
    invoice_type: InvoiceType = "GOODS"
    amount: float
    tax_amount: float = 0.0
    lines: List[InvoiceLine]
    po_id: Optional[str] = None
    gr_ids: List[str] = []
    external_ref: Optional[str] = None

    @field_validator("amount")
    @classmethod
    def _amount_positive(cls, v):
        assert v >= 0, "amount must be >= 0"
        return v

class POLine(BaseModel):
    po_line_id: str
    description: str
    qty: float
    unit_price: float
    currency: Currency = "USD"

class PO(BaseModel):
    po_id: str
    supplier_id: str
    lines: List[POLine]

class GRLine(BaseModel):
    po_line_id: str
    qty_received: float

class GRN(BaseModel):
    gr_id: str
    po_id: str
    lines: List[GRLine]

class Vendor(BaseModel):
    vendor_id: str
    name: str
    country: str = "US"
    tax_form: Optional[Literal["W-9","W-8BEN","W-8BEN-E"]] = None
    tin: Optional[str] = None
    ofac_status: Literal["unknown","pass","review","fail"] = "unknown"
    ach: Optional[dict] = None  # {"routing": "...", "account": "...", "sec": "CCD"}

class Approval(BaseModel):
    approver: str
    role: str
    amount_limit: float

class ApprovalMatrix(BaseModel):
    currency: Currency = "USD"
    rules: List[dict]  # [{ "min":0, "max":5000, "approvers":[{"approver":"mgr1","role":"Manager"}]}]

class PaymentEntry(BaseModel):
    vendor_id: str
    invoice_id: str
    amount: float
    routing: str
    account: str
    sec: SecCode = "CCD"

class NachaFile(BaseModel):
    file_content: str  # 94-char fixed width lines joined by \n
    control_totals: dict

class Evidence(BaseModel):
    trace_id: str
    artifacts: Dict[str, str]  # name -> path
