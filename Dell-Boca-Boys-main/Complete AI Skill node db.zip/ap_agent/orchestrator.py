
from __future__ import annotations
import uuid, time
from typing import Dict, Any, Callable, List
import importlib

class Orchestrator:
    def __init__(self, registry: dict):
        self.registry = registry
        self.trace_id = f"ap-{uuid.uuid4().hex[:12]}"
        self.node_map: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {}
        # lazy import functions
        self._bind("intake.validate_invoice_basics","ap_agent.nodes.intake","validate_invoice_basics")
        self._bind("vendor.lookup","ap_agent.nodes.vendor","lookup")
        self._bind("vendor.sanctions_screen","ap_agent.nodes.sanctions","sanctions_screen")
        self._bind("match.retrieve_po_gr","ap_agent.nodes.matching","retrieve_po_gr")
        self._bind("match.perform_match","ap_agent.nodes.matching","perform_match")
        self._bind("ap.detect_duplicates_fraud","ap_agent.nodes.duplicate","detect_duplicates")
        self._bind("controls.enforce_sod","ap_agent.nodes.sod","enforce_sod")
        self._bind("payments.generate_nacha","ap_agent.nodes.payments","generate_nacha")
        self._bind("payments.reconcile","ap_agent.nodes.recon","reconcile")
        self._bind("audit.bundle","ap_agent.nodes.audit","bundle")

    def _bind(self, node_id: str, module: str, func: str):
        mod = importlib.import_module(module)
        fn = getattr(mod, func)
        self.node_map[node_id] = fn

    def run(self, plan: List[str], context: Dict[str, Any]) -> Dict[str, Any]:
        context = dict(context)  # copy
        context["trace_id"] = self.trace_id
        for node_id in plan:
            t0 = time.time()
            fn = self.node_map[node_id]
            context = fn(context)  # nodes must return updated context
            context.setdefault("telemetry", []).append({
                "node": node_id,
                "elapsed_ms": int((time.time()-t0)*1000)
            })
            # human-in-the-loop safety: stop if sanctions fail or match hard-fail
            if context.get("vendor",{}).get("ofac_status") == "fail":
                context["halt_reason"] = "OFAC_FAIL"
                break
            if context.get("match_report",{}).get("status") == "exception":
                context["halt_reason"] = "MATCH_EXCEPTION"
                break
        return context
