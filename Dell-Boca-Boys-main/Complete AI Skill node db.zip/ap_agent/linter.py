
from __future__ import annotations
import json, re
from pathlib import Path

REQUIRED_NODE_FIELDS = {"id","intent","inputs","outputs"}

def lint_registry(path: str) -> list[dict]:
    p = Path(path)
    data = json.loads(p.read_text())
    issues = []
    if "nodes" not in data or not isinstance(data["nodes"], list):
        issues.append({"id":"registry.structure","level":"error","msg":"nodes[] missing"})
        return issues
    ids = set()
    for node in data["nodes"]:
        missing = REQUIRED_NODE_FIELDS - set(node)
        if missing:
            issues.append({"id":node.get("id","<unknown>"),"level":"error","msg":f"missing fields: {sorted(missing)}"})
        if " " in node["id"]:
            issues.append({"id":node["id"],"level":"error","msg":"id contains spaces"})
        if node["id"] in ids:
            issues.append({"id":node["id"],"level":"error","msg":"duplicate id"})
        ids.add(node["id"])
        # determinism check: intent length
        if len(node["intent"]) < 10:
            issues.append({"id":node["id"],"level":"warn","msg":"intent possibly too short"})
        # inputs/outputs types
        if not isinstance(node["inputs"], list) or not isinstance(node["outputs"], list):
            issues.append({"id":node["id"],"level":"error","msg":"inputs/outputs must be lists"})
    return issues

if __name__ == "__main__":
    import sys
    issues = lint_registry(sys.argv[1] if len(sys.argv)>1 else "ap_agent/registry.json")
    for i in issues:
        print(f"{i['level'].upper()}: {i['id']}: {i['msg']}")
    if any(i["level"]=="error" for i in issues):
        raise SystemExit(1)
