
from __future__ import annotations
from typing import Dict, Any, List

# A deterministic planner based on required inputs/outputs
PIPELINE = [
    "intake.validate_invoice_basics",
    "vendor.lookup",
    "vendor.sanctions_screen",
    "match.retrieve_po_gr",
    "match.perform_match",
    "ap.detect_duplicates_fraud",
    "controls.enforce_sod",
    # payments and recon are executed later when batching
]

def plan(context: Dict[str, Any]) -> List[str]:
    # human-in-the-loop: if sanctions fail or match fails -> stop before payments
    dag = []
    for nid in PIPELINE:
        dag.append(nid)
    return dag
