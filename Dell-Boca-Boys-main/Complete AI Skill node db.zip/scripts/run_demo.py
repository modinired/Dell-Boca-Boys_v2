
from ap_agent.orchestrator import Orchestrator
from ap_agent import Orchestrator as _
import json

from ap_agent.planner import plan
import ap_agent.linter as linter
import ap_agent

# Load registry and lint
import pathlib, os
reg_path = os.path.join(os.path.dirname(ap_agent.__file__), "registry.json")
issues = linter.lint_registry(reg_path)
assert not any(i["level"]=="error" for i in issues), issues

registry = json.loads(open(reg_path).read())
orc = Orchestrator(registry)

invoice = {
    "invoice_id": "INV-777",
    "supplier_name": "Acme Components",
    "invoice_date": "2025-09-15",
    "due_date": "2025-10-15",
    "terms": "2/10 Net 30",
    "currency": "USD",
    "invoice_type": "GOODS",
    "amount": 100*10.00 + 200*0.50,  # 200.0
    "po_id": "PO-1001",
    "lines": [
        {"line_id":"1","description":"Widgets","qty":100,"unit_price":10.00,"currency":"USD","po_line_id":"PO-1001-1"},
        {"line_id":"2","description":"Bolts","qty":180,"unit_price":0.50,"currency":"USD","po_line_id":"PO-1001-2"}
    ]
}

ctx = {"invoice": invoice}
dag = plan(ctx)
ctx = orc.run(dag, ctx)

# If not halted, simulate approvals and payment
if "halt_reason" not in ctx:
    # mark approvals complete (human-in-the-loop gating)
    ctx["approval_route"]["status"] = "approved"
    ctx["payment_entries"] = [{
        "vendor_id": ctx["vendor"]["vendor_id"],
        "invoice_id": invoice["invoice_id"],
        "amount": invoice["amount"],
        "routing": ctx["vendor"]["ach"]["routing"],
        "account": ctx["vendor"]["ach"]["account"],
        "sec": "CCD"
    }]
    ctx = orc.node_map["payments.generate_nacha"](ctx)
    ctx["invoices"] = [invoice]
    ctx = orc.node_map["payments.reconcile"](ctx)
    ctx = orc.node_map["audit.bundle"](ctx)

out_path = "/mnt/data/ap_agent/demo_output.json"
open(out_path,"w").write(json.dumps(ctx, indent=2))
print("WROTE", out_path)
