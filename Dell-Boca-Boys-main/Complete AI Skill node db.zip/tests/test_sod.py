
from ap_agent.nodes.sod import enforce_sod
def test_sod_routes():
    ctx = {"invoice":{"amount":6000}}
    ctx = enforce_sod(ctx)
    assert len(ctx["approval_route"]["required"])>=1
