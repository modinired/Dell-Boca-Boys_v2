
from ap_agent.nodes.matching import perform_match
def test_match_success():
    ctx = {
        "invoice":{
            "invoice_id":"X","supplier_name":"Acme Components","invoice_date":"2025-09-15","due_date":"2025-10-15",
            "invoice_type":"GOODS","amount":200.0,"po_id":"PO-1001",
            "lines":[
                {"line_id":"1","description":"Widgets","qty":100,"unit_price":10.00,"currency":"USD","po_line_id":"PO-1001-1"},
                {"line_id":"2","description":"Bolts","qty":180,"unit_price":0.50,"currency":"USD","po_line_id":"PO-1001-2"},
            ]
        },
        "po":{"po_id":"PO-1001","supplier_id":"VEND-001","lines":[
            {"po_line_id":"PO-1001-1","description":"Widgets","qty":100,"unit_price":10.00,"currency":"USD"},
            {"po_line_id":"PO-1001-2","description":"Bolts","qty":200,"unit_price":0.50,"currency":"USD"}
        ]},
        "grns":[
            {"gr_id":"GR-900","po_id":"PO-1001","lines":[{"po_line_id":"PO-1001-1","qty_received":100}]},
            {"gr_id":"GR-901","po_id":"PO-1001","lines":[{"po_line_id":"PO-1001-2","qty_received":180}]}
        ]
    }
    ctx = perform_match(ctx)
    assert ctx["match_report"]["status"] in ("match","tolerance")
