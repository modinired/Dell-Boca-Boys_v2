
from ap_agent.nodes.payments import generate_nacha

def test_nacha_builds():
    ctx = {"payment_entries":[{"vendor_id":"VEND-001","invoice_id":"INV-1","amount":123.45,"routing":"091000019","account":"1234567890","sec":"CCD"}]}
    ctx = generate_nacha(ctx)
    content = ctx["nacha_file"]["file_content"]
    lines = content.splitlines()
    assert lines[0].startswith("1")
    assert lines[1].startswith("5")
    assert any(l.startswith("6") for l in lines)
    assert lines[-2].startswith("8")
    assert lines[-1].startswith("9")
    assert all(len(l)==94 for l in lines)
