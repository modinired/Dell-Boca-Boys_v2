# AP Agent (Accounts Payable)

Production-grade, local-first package implementing:
- Skills registry (`ap_agent/registry.json`)
- JSON schema + linter (`ap_agent/linter.py`)
- Deterministic planner (`ap_agent/planner.py`) and DAG executor (`ap_agent/orchestrator.py`)
- Real node implementations (matching, OFAC screening, SoD checks, NACHA generation, reconciliation, audit bundle)
- Runnable demo (`scripts/run_demo.py`)
- Pytests under `tests/`

> No network calls. All logic runs locally. Integrations can be added via adapter interfaces.
