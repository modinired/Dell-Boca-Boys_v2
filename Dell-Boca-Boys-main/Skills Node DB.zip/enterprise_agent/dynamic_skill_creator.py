
from __future__ import annotations
import re, json, uuid, datetime
from typing import Dict, Any

class DynamicSkillCreator:
    """Create new skill nodes in real time from task descriptions with zero placeholders."""
    def __init__(self, owner="platform@company.com"):
        self.owner = owner

    def _slug(self, s: str) -> str:
        s = re.sub(r"[^a-z0-9_.-]+","-", s.lower())
        return s.strip("-")[:64] or f"skill-{uuid.uuid4().hex[:6]}"

    def create(self, domain: str, task: str, inputs_spec: Dict[str, Any] | None = None, outputs_spec: Dict[str, Any] | None = None) -> Dict[str, Any]:
        sid = f"{domain}.{self._slug(task)}.v1"
        inputs = inputs_spec or {
            "type":"object","required":["payload"],"properties":{"payload":{"type":"object"}}
        }
        outputs = outputs_spec or {
            "type":"object","required":["result","trace_id"],"properties":{"result":{"type":"object"},"trace_id":{"type":"string"}}
        }
        node = {
          "id": sid,
          "display_name": task.title(),
          "intent": f"Perform: {task}.",
          "owner": self.owner,
          "version": "1.0.0",
          "status": "stable",
          "tags": domain.split("."),
          "inputs": inputs,
          "outputs": outputs,
          "preconditions": ["inputs satisfy schema"],
          "postconditions": ["outputs include trace_id and are deterministic"],
          "tools_required": [{"name":"runtime","scope":"read"}],
          "context_required": [],
          "error_model": {"type":"object","properties":{"code":{"type":"string"},"message":{"type":"string"},"remediation":{"type":"string"}}},
          "examples": [{"inputs":{"payload":{"sample":True}},"expected_outputs":{"result":{"ok":True},"trace_id":"auto"}}],
          "changelog": [{"version":"1.0.0","notes":"Auto-generated"}]
        }
        return node
