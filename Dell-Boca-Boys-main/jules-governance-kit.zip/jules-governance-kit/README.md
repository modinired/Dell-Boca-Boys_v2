# Jules Governance Kit (Universal Seed) — v1.0.1

This repository is a **drop-in governance layer** that enforces the Jules Protocol v2 guardrails for any project.
It includes:
- A **Pre-Build Gate** (`governance/prebuild.sh`) for audit & operational compliance.
- **Machine-enforced guardrails** via JSON Schema + OPA (Rego).
- **Producer scripts** to compile coverage/duplication/junit/docmap into a single `governance/compliance_input.json`.
- A single **Makefile** entrypoint and **CI template**.
- A **language matrix** (Node, Python, Go, Java) with tiny sample modules & tests.

## Quickstart (Local)
```bash
make all        # runs prebuild → build → tests → compliance
make compliance # produce compliance_input.json and enforce policy
```

## CI
Use `.github/workflows/jules-governance.yml`

## Language Matrix
See `/matrix` subfolders for language-specific examples and commands to emit reports to `governance/reports/`.
