#!/usr/bin/env bash
set -euo pipefail

echo "[PREBUILD] Jules Pre-Build Gate — audit & ops compliance"

echo "[CHECK] OS/CPU/Tools"
uname -a
command -v node >/dev/null || (echo "node missing" && exit 1)
command -v npm >/dev/null || (echo "npm missing" && exit 1)
command -v python3 >/dev/null || (echo "python3 missing" && exit 1)
command -v jq >/dev/null || (echo "jq missing" && exit 1)

echo "[CHECK] Lockfiles"
if [ -f package.json ]; then test -f package-lock.json -o -f pnpm-lock.yaml -o -f yarn.lock || (echo "JS lockfile missing" && exit 1); fi

echo "[CHECK] No plaintext secrets tracked"
! git ls-files | grep -E '(\.pem|\.p12|id_rsa|id_dsa|\.key|credentials\.json|secrets?\.(json|yaml|yml)|\.env$)' && echo "OK" || (echo "Secret-like files tracked. Remove/migrate to env." && exit 1)

echo "[CHECK] Governance manifest hash"
python3 - <<'PY'
import hashlib, json
h = hashlib.sha256(open("governance/manifest.yml","rb").read()).hexdigest()
lock = json.load(open("governance/manifest.lock"))
assert lock["sha256"] == h, f"manifest.lock mismatch: {lock['sha256']} != {h}"
print("manifest hash OK:", h)
PY

echo "[CHECK] docs/_validation_map.json"
test -f docs/_validation_map.json || (echo "docs/_validation_map.json missing" && exit 1)
jq '.claims | length' docs/_validation_map.json >/dev/null

echo "[TRACE] governance/trace.json present"
test -f governance/trace.json || echo '{"task_id":"bootstrap","timestamp_utc":"1970-01-01T00:00:00Z","jules_version":"1.0.0","inputs":{"summary":"bootstrap","files":[],"parameters":{}},"decisions":[],"dependencies":[],"licenses":[],"requires_review":false,"override_events":[]}' > governance/trace.json

echo "[SETUP] Installing governance dev deps"
npm ci

echo "[OPTIONAL] SBOM + vuln scan"
make sbom vuln || true

echo "[PREBUILD] OK"
