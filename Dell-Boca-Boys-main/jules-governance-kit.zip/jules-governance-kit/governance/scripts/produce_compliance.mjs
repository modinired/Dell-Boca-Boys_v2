#!/usr/bin/env node
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs-extra";
import {
  readJsonIfExists, readTextIfExists, writeJson, sha256,
  coberturaToRatio, lcovToRatio, duplicationFromJscpd, junitCounts
} from "./utils.mjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, "../../..");
const GOV = (p) => path.join(ROOT, "governance", p);

const COVERAGE_XML = GOV("reports/coverage.xml");
const LCOV_INFO    = GOV("reports/lcov.info");
const JSCPD_JSON   = GOV("reports/jscpd-report.json");
const JUNIT_XML    = GOV("reports/junit.xml");
const DOCMAP_JSON  = path.join(ROOT, "docs/_validation_map.json");
const CRON_JSON    = path.join(ROOT, "logs/cron_status.json");
const COMPAT_JSON  = GOV("backward_compat.json");
const MANIFEST_YML = GOV("manifest.yml");
const MANIFEST_LOCK= GOV("manifest.lock");
const OUT = GOV("compliance_input.json");

(async () => {
  let lint_pass = true, type_pass = true, tests_pass = true, security_pass = true;

  let coverage = null;
  const covXml = await readTextIfExists(COVERAGE_XML);
  if (covXml) coverage = coberturaToRatio(covXml);
  if (coverage === null) {
    const lcov = await readTextIfExists(LCOV_INFO);
    if (lcov) coverage = lcovToRatio(lcov);
  }
  if (coverage === null) coverage = 0;

  const jscpd = await readJsonIfExists(JSCPD_JSON);
  let duplication_rate = duplicationFromJscpd(jscpd || {}) ?? 1;

  const docmap = await readJsonIfExists(DOCMAP_JSON);
  let doc_claims_total = 0, doc_claims_tested = 0;
  if (docmap && Array.isArray(docmap.claims)) {
    doc_claims_total = docmap.claims.length;
    doc_claims_tested = docmap.claims.filter(c => c.tested === true).length;
  }

  const junit = await readTextIfExists(JUNIT_XML);
  let success_tests = 0, failure_tests = 0;
  if (junit) {
    const { success, failurePath } = junitCounts(junit);
    success_tests = success;
    failure_tests = failurePath;
  }

  const cron = await readJsonIfExists(CRON_JSON);
  const cron_verified = !!(cron && cron.last_run_ok === true && typeof cron.spec === "string");

  const compat = await readJsonIfExists(COMPAT_JSON);
  const backward_compat = !!(compat && compat.compat === true);

  const manifest = await readTextIfExists(MANIFEST_YML);
  const lock = await readJsonIfExists(MANIFEST_LOCK);
  const governance_hash_ok = !!(manifest && lock && lock.sha256 === sha256(manifest));

  const out = {
    lint_pass, type_pass, tests_pass, security_pass,
    coverage, duplication_rate,
    doc_claims_total, doc_claims_tested,
    failure_tests, success_tests,
    cron_verified, user_doubt: false,
    backward_compat, governance_hash_ok,
    notes: "Produced by governance/scripts/produce_compliance.mjs"
  };

  await writeJson(OUT, out);
  console.log(`Wrote ${OUT}`);
})();
