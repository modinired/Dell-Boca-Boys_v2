import fs from "fs-extra";
import crypto from "crypto";
import { XMLParser } from "fast-xml-parser";

export async function readJsonIfExists(p){ try { return await fs.readJson(p); } catch { return null; } }
export async function readTextIfExists(p){ try { return await fs.readFile(p,"utf8"); } catch { return null; } }
export async function writeJson(p,obj){ await fs.ensureDir(require("path").dirname(p)); await fs.writeJson(p,obj,{spaces:2}); }
export function sha256(s){ return crypto.createHash("sha256").update(s).digest("hex"); }

export function coberturaToRatio(xmlString){
  const parser = new XMLParser({ ignoreAttributes:false, attributeNamePrefix:"" });
  const data = parser.parse(xmlString);
  const rate = Number(data?.coverage?.["line-rate"]);
  if (!Number.isFinite(rate)) return null;
  return Math.max(0, Math.min(1, rate));
}

export function lcovToRatio(lcovText){
  let linesFound=0, linesHit=0;
  for (const line of lcovText.split("\n")){
    if (line.startsWith("LF:")) linesFound += Number(line.slice(3));
    if (line.startsWith("LH:")) linesHit += Number(line.slice(3));
  }
  if (linesFound <= 0) return null;
  return Math.max(0, Math.min(1, linesHit/linesFound));
}

export function duplicationFromJscpd(json){
  const pct = Number(json?.statistics?.percentage);
  if (Number.isFinite(pct)) return Math.max(0, Math.min(1, pct/100));
  const dup = Number(json?.summary?.total?.duplicatedLines);
  const total = Number(json?.summary?.total?.lines);
  if (Number.isFinite(dup) && Number.isFinite(total) && total>0){
    return Math.max(0, Math.min(1, dup/total));
  }
  return null;
}

export function junitCounts(xmlString){
  const parser = new XMLParser({ ignoreAttributes:false, attributeNamePrefix:"" });
  const data = parser.parse(xmlString);
  const cases = [];
  function collect(node){
    if (!node) return;
    if (Array.isArray(node)) node.forEach(collect);
    else {
      if (node.testcase) collect(node.testcase);
      if (Array.isArray(node.testcase)) node.testcase.forEach(collect);
      if (node.name && node.classname !== undefined) cases.push(node);
    }
  }
  collect(data.testsuite || data.testsuites);
  let success=0, failurePath=0;
  for (const tc of cases){
    const name = String(tc.name || "").toLowerCase();
    const isFailurePath = name.includes("[failure]") || name.endsWith("_fails") || name.includes("::fail");
    success += 1;
    if (isFailurePath) failurePath += 1;
  }
  return { success, failurePath };
}
