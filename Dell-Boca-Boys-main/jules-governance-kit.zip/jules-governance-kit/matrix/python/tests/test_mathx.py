import pytest
from src.mathx import mul

def test_mul_ok():
    assert mul(2,5)==10

def test_mul_failure_path_fails():
    # [failure] behavior example: invalid types should raise TypeError
    with pytest.raises(TypeError):
        _ = mul("x", 3)  # type: ignore
