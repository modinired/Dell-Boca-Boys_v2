# Go Matrix Instructions
```bash
cd matrix/go
go test ./... -coverprofile=coverage.out -covermode=count -json > test.json
# Convert coverage to Cobertura (install github.com/boumenot/gocover-cobertura or use any converter)
# Example (requires tool):
# go install github.com/boumenot/gocover-cobertura@latest
# gocover-cobertura < coverage.out > ../governance/reports/coverage.xml
# Convert test.json to JUnit (requires go-junit-report)
# go install github.com/jstemmer/go-junit-report/v2@latest
# cat test.json | go-junit-report -set-exit-code > ../governance/reports/junit.xml
```
