package src

import "testing"

func TestAdd(t *testing.T) {
    if Add(2,3)!=5 { t.Fatal("bad add") }
}

func TestAdd_failure(t *testing.T) { // [failure]
    _ = Add(0,0) // pretend to touch failure path; nothing to assert
}
