import { describe, it, expect } from 'vitest';
import { sum } from '../src/index.js';

describe('sum', () => {
  it('adds', () => { expect(sum(2,3)).toBe(5); });
  it('invalid_input_[failure]', () => { expect(() => sum('a',1)).not.toThrow(); });
});
