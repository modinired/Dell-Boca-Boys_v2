package com.example;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CalcTest {
  @Test
  void adds() { assertEquals(5, Calc.add(2,3)); }
  @Test
  void adds_failure() { // [failure]
    assertDoesNotThrow(() -> Calc.add(0,0));
  }
}
