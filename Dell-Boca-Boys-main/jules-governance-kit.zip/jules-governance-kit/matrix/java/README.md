# Java Matrix Instructions (Maven + JUnit + JaCoCo)
```bash
cd matrix/java
mvn -q -DskipTests=false test
# JaCoCo XML report: target/site/jacoco/jacoco.xml
# Copy to governance reports:
cp target/site/jacoco/jacoco.xml ../governance/reports/coverage.xml
# Surefire JUnit XML is already in ../governance/reports
```
