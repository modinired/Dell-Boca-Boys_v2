
from enterprise_agent.dynamic_skill_creator import DynamicSkillCreator
from enterprise_agent.linter import lint_node
import json

creator = DynamicSkillCreator()
node = creator.create("finance.fpa","scenario planning for commodity price shock with elasticity curve fit")
errs = lint_node(node)
assert not errs, errs
out = "/mnt/data/enterprise_agent/dynamic_node.json"
open(out,"w").write(json.dumps(node, indent=2))
print("WROTE", out)
