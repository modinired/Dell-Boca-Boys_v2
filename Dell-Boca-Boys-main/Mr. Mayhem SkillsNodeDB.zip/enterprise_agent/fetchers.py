
from __future__ import annotations
import os, hashlib, time, requests, sqlite3, json
from typing import Optional

DEFAULT_TIMEOUT = 60

OFAC_SDN_URL = "https://www.treasury.gov/ofac/downloads/sdn.csv"  # official CSV
PEPPOL_BIS_URL = "https://docs.peppol.eu/poacc/billing/3.0/bis/"  # spec index
NACHA_GUIDE_URL = "https://www.nacha.org"  # landing; vendors may require auth for full rulebook

def _hash_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def _ensure_dir(p: str):
    os.makedirs(os.path.dirname(p), exist_ok=True)

def _save(path: str, content: bytes):
    _ensure_dir(path)
    with open(path, "wb") as f:
        f.write(content)

def fetch_url(url: str, timeout=DEFAULT_TIMEOUT, headers: Optional[dict]=None) -> bytes:
    r = requests.get(url, timeout=timeout, headers=headers or {"User-Agent":"EnterpriseSkillsSuite/1.0"})
    r.raise_for_status()
    return r.content

def update_source(db_path: str, key: str, url: str, local_path: str) -> dict:
    """Download a resource, compute hash, and store/replace in sources table atomically."""
    b = fetch_url(url)
    h = _hash_bytes(b)
    _save(local_path, b)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("""
        INSERT OR REPLACE INTO sources (key, source_type, local_path, url, hash, updated_at)
        VALUES (?,?,?,?,?,datetime('now'))
    """, (key, "binary", local_path, url, h))
    conn.commit()
    return {"key": key, "hash": h, "bytes": len(b), "path": local_path, "url": url}

def refresh_ofac(db_path: str, mirror_dir: str) -> dict:
    path = os.path.join(mirror_dir, "ofac_sdn.csv")
    return update_source(db_path, "ofac_sdn", OFAC_SDN_URL, path)

def refresh_peppol(db_path: str, mirror_dir: str) -> dict:
    # Save HTML index (hash-tracked); downstream validators can scrape anchors/versions if needed.
    path = os.path.join(mirror_dir, "peppol_bis_index.html")
    return update_source(db_path, "peppol_bis", PEPPOL_BIS_URL, path)

def refresh_nacha(db_path: str, mirror_dir: str) -> dict:
    # NACHA rulebook is paywalled; we track the landing page to detect changes + maintain local NACHA meta JSON.
    path = os.path.join(mirror_dir, "nacha_landing.html")
    return update_source(db_path, "nacha_meta", NACHA_GUIDE_URL, path)

def refresh_all(db_path: str, mirror_dir: str) -> list[dict]:
    os.makedirs(mirror_dir, exist_ok=True)
    results = []
    for fn in (refresh_ofac, refresh_peppol, refresh_nacha):
        try:
            results.append(fn(db_path, mirror_dir))
        except Exception as e:
            results.append({"error": str(e)})
    return results
