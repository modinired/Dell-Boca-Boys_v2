
from __future__ import annotations
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import sqlite3, json, os
from typing import List
from enterprise_agent.linter import lint_node
from enterprise_agent.auto_updater import AutoUpdater

DB = os.path.join(os.path.dirname(__file__), "..", "db", "enterprise.db")
POL = os.path.join(os.path.dirname(__file__), "..", "policies", "update_policies.yaml")

app = FastAPI(title="Enterprise Agent Skill API", version="1.0.0")

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

class SkillPayload(BaseModel):
    node: dict

@app.get("/skills/{skill_id}")
def get_skill(skill_id: str):
    cur = conn().cursor()
    cur.execute("SELECT * FROM skills WHERE id=?", (skill_id,))
    r = cur.fetchone()
    if not r:
        raise HTTPException(404, "skill not found")
    return {"id": r["id"], "registry": r["registry"], "node": json.loads(r["node"]), "version": r["version"]}

@app.post("/skills")
def create_skill(payload: SkillPayload):
    errs = lint_node(payload.node)
    if errs:
        raise HTTPException(400, {"linter": errs})
    c = conn()
    cur = c.cursor()
    cur.execute("INSERT OR REPLACE INTO skills (id, registry, node, version, updated_at) VALUES (?,?,?,?,datetime('now'))",
                (payload.node["id"], "api", json.dumps(payload.node), payload.node["version"]))
    c.commit()
    return {"ok": True}

@app.get("/golden/{role}")
def get_golden(role: str):
    cur = conn().cursor()
    cur.execute("SELECT content FROM golden_commands WHERE role=?", (role,))
    r = cur.fetchone()
    if not r: raise HTTPException(404, "role not found")
    return {"role": role, "content": r["content"]}

@app.post("/update/{namespace}")
def run_update(namespace: str):
    updater = AutoUpdater(DB, POL)
    result = updater.validate_and_bump(namespace)
    return result
