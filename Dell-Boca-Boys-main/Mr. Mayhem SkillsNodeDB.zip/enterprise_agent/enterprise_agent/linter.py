
from __future__ import annotations
import json, re, sys
from pathlib import Path

def _assert(cond, msg, errs):
    if not cond:
        errs.append(msg)

def lint_node(node: dict) -> list[str]:
    errs: list[str] = []
    required = ["id","display_name","intent","owner","version","status","tags","inputs","outputs","preconditions","postconditions","tools_required","context_required","error_model","examples","changelog"]
    for k in required:
        _assert(k in node, f"missing {k}", errs)
    _assert(bool(re.match(r"^[a-z0-9_.-]+$", node.get("id",""))), "id must be kebab/camel with dot/underscore only", errs)
    # outputs must include trace_id
    out_props = node.get("outputs",{}).get("properties",{})
    _assert("trace_id" in out_props, "outputs must include trace_id", errs)
    # each numeric field should include units unless enum
    def walk(obj, path=""):
        if isinstance(obj, dict):
            if obj.get("type")=="number":
                if "enum" not in obj:
                    _assert("units" in obj, f"numeric field missing units at {path}", errs)
            for k,v in obj.items():
                if isinstance(v,(dict,list)):
                    walk(v, path+f".{k}")
        elif isinstance(obj, list):
            for i,v in enumerate(obj):
                walk(v, path+f"[{i}]")
    walk(node.get("inputs",{}), "inputs")
    walk(node.get("outputs",{}), "outputs")
    # at least one example
    _assert(len(node.get("examples",[]))>=1, "at least one example required", errs)
    return errs

def lint_registry(path: str) -> list[str]:
    data = json.loads(Path(path).read_text())
    errs_all = []
    seen = set()
    for n in data.get("skills",[]):
        if n["id"] in seen:
            errs_all.append(f"duplicate id: {n['id']}")
        seen.add(n["id"])
        errs = lint_node(n)
        errs_all += [f"[{n['id']}] {e}" for e in errs]
    return errs_all

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("registry")
    args = ap.parse_args()
    errs = lint_registry(args.registry)
    if errs:
        print("LINTER FAILED")
        for e in errs: print(" -", e)
        raise SystemExit(1)
    print("LINTER PASSED")
