
from __future__ import annotations
import sqlite3, json, fnmatch, datetime, hashlib, os, yaml
from typing import Dict, Any, List

class AutoUpdater:
    def __init__(self, db_path: str, policy_path: str):
        self.db = sqlite3.connect(db_path)
        self.db.row_factory = sqlite3.Row
        self.policies = yaml.safe_load(open(policy_path))

    def _get_skills(self, namespace: str) -> List[dict]:
        cur = self.db.cursor()
        cur.execute("SELECT id, registry, node, version FROM skills WHERE registry LIKE ?", (f"%{namespace.replace('.','_')}%",))
        skills = []
        for r in cur.fetchall():
            node = json.loads(r["node"])
            skills.append(node)
        return skills

    def _get_source(self, key: str) -> dict:
        cur = self.db.cursor()
        cur.execute("SELECT * FROM sources WHERE key=?", (key,))
        row = cur.fetchone()
        if not row: 
            raise RuntimeError(f"source missing: {key}")
        return dict(row)

    def validate_and_bump(self, namespace: str) -> Dict[str, Any]:
        pol = self.policies.get(namespace, {})
        if not pol:
            return {"namespace": namespace, "checked":0, "updated":0, "notes":"no policy"}
        rules = pol.get("rules", [])
        skills = self._get_skills(namespace)
        updated = 0
        checked = 0
        for s in skills:
            sid = s["id"]
            for rule in rules:
                if fnmatch.fnmatch(sid, rule["match"]):
                    # simple validation: ensure source exists and non-empty; embed hash in changelog
                    src_key = rule["action"].split(":")[1]
                    src = self._get_source(src_key)
                    stat = os.stat(src["local_path"])
                    if stat.st_size > 0:
                        # bump patch version and add changelog entry with source hash
                        major, minor, patch = map(int, s["version"].split("."))
                        patch += 1
                        s["version"] = f"{major}.{minor}.{patch}"
                        s.setdefault("changelog", []).append({
                            "version": s["version"],
                            "notes": f"Auto-validated against {src_key} (hash={src['hash']}) on {datetime.datetime.utcnow().isoformat()}Z"
                        })
                        # write back
                        cur = self.db.cursor()
                        cur.execute("UPDATE skills SET node=?, version=?, updated_at=? WHERE id=?",
                                    (json.dumps(s, ensure_ascii=False), s["version"], datetime.datetime.utcnow().isoformat()+"Z", sid))
                        self.db.commit()
                        updated += 1
                    checked += 1
        return {"namespace": namespace, "checked": checked, "updated": updated}
