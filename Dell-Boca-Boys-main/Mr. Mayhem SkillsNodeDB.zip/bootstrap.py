
#!/usr/bin/env python3
"""
Bootstraps the Enterprise Skills Suite:
 - Runs live fetchers for OFAC/Peppol/NACHA
 - Executes policy-based auto-updates for key namespaces
 - Prints a concise summary
"""
import os, json, sqlite3, sys
from enterprise_agent.fetchers import refresh_all
from enterprise_agent.auto_updater import AutoUpdater

ROOT = os.path.dirname(__file__)
DB = os.path.join(ROOT, "enterprise_agent", "db", "enterprise.db")
MIR = os.path.join(ROOT, "enterprise_agent", "mirrors")
POL = os.path.join(ROOT, "enterprise_agent", "policies", "update_policies.yaml")

print("Refreshing authoritative sources...")
results = refresh_all(DB, MIR)
print(json.dumps(results, indent=2))

print("\nRunning policy-based updates...")
au = AutoUpdater(DB, POL)
for ns in ["finance.ap", "finance.payroll"]:
    out = au.validate_and_bump(ns)
    print(ns, "->", out)

print("\nDone.")
