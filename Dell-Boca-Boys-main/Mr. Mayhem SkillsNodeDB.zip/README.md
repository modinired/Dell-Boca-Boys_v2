# Enterprise Skills Suite (Production)

**What this is:** A full, production-ready system for enterprise skill nodes across S&P 500 job families, including:
- Universal skill schema & linter
- Departmental registries + base core skills
- Dynamic Skill Creator
- SQLite persistence (skills, sources, golden commands)
- FastAPI admin API (CRUD, linter, golden, updates)
- Live fetchers (OFAC SDN, Peppol BIS index, NACHA landing) with hash evidence
- Policy-driven Auto-Updater that validates nodes per position type and **bumps versions with signed changelog entries**
- Example AP agent (end-to-end) and tests

## Quick Start
```bash
unzip enterprise_skills_suite.zip
cd enterprise_skills_suite

# 1) (Optional) create venv & install deps
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt

# 2) Initialize sources and run updates
python bootstrap.py

# 3) Start API
uvicorn enterprise_agent.api.app:app --host 0.0.0.0 --port 8080
# visit http://localhost:8080/docs
```

## Layout
- `enterprise_agent/` – code, registries, DB, policies, API, fetchers, updater
- `bootstrap.py` – refresh live sources, run updates
- `requirements.txt` – concrete versions for reproducibility

## Guarantees
- **Deterministic contracts**: typed inputs/outputs + `trace_id`
- **Controls**: SoD, 3/4-way match, duplicate detection, ACH format validation
- **Auditability**: source hashes in skill changelogs, evidence zip in AP flow
- **No placeholders**: every node has examples, contracts, and enforced linter rules

## CI
A GitHub Actions workflow runs linter + a smoke Update job and fails on any violation.

---

© 2025 CESAR / Terry Delmonaco Co.
